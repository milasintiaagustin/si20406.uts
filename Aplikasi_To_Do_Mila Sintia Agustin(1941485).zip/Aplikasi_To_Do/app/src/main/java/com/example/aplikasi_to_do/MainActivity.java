package com.example.aplikasi_to_do;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    CheckBox kerja1, kerja2, kerja3, kerja4, kerja5;
    EditText input, textView4;
    String kerja_1, kerja_2, kerja_3, kerja_4, kerja_5;
    Button tambah, hapus, hapus2, hapus3, hapus4, hapus5;

    private ArrayList<String> items;
    private ArrayAdapter<String> itemsAdapter;
    private ListView listView;
    private CheckBox checkBox;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        kerja1 = (CheckBox) findViewById(R.id.kerja1);
        kerja2 = (CheckBox) findViewById(R.id.kerja2);
        kerja3 = (CheckBox) findViewById(R.id.kerja3);
        kerja4 = (CheckBox) findViewById(R.id.kerja4);
        kerja5 = (CheckBox) findViewById(R.id.kerja5);


        setCheckBoxListener();
        setButtonListener();

        input = (EditText) findViewById(R.id.input);
        tambah = (Button) findViewById(R.id.tambah);
        hapus = (Button) findViewById(R.id.hapus);
        hapus2 = (Button) findViewById(R.id.hapus2);
        hapus3 = (Button) findViewById(R.id.hapus3);
        hapus4 = (Button) findViewById(R.id.hapus4);
        hapus5 = (Button) findViewById(R.id.hapus5);

        tambah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { addItem(view); }

            private void addItem(View view) {
            }
        });


    }

    private void setButtonListener() {
    }

    private void setCheckBoxListener() {
        kerja1 = (CheckBox) findViewById(R.id.kerja1);
        kerja1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (((CheckBox) view).isChecked()) {
                    Toast.makeText(MainActivity.this, "Pekerjaan 1", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void onCheckboxClicked (View view) {
        boolean checked = ((CheckBox) view).isChecked();

        if(kerja1.isChecked()){
            kerja_1 = "Pekerjaan 1";
        }else if(!kerja1.isChecked()){
             kerja_1= " ";
        }

        if(kerja2.isChecked()){
            kerja_2 = "Pekerjaan 2";
        }else if(!kerja2.isChecked()){
            kerja_2= " ";
        }

        if(kerja3.isChecked()){
            kerja_3 = "Pekerjaan 3";
        }else if(!kerja3.isChecked()){
            kerja_3= " ";
        }

        if(kerja4.isChecked()){
            kerja_4 = "Pekerjaan 4";
        }else if(!kerja4.isChecked()){
            kerja_4= " ";
        }


        Toast.makeText(getApplicationContext(), "Pekerjaan Selesai", Toast.LENGTH_SHORT).show();
        textView4.setText(kerja_1);


        switch(view.getId()) {
            case R.id.kerja1:
                if (checked)
                        break;
            case R.id.kerja2:
                if (checked)
                        break;
            case R.id.kerja3:
                if (checked)
                        break;
            case R.id.kerja4:
                if (checked)
                        break;
            case R.id.kerja5:
                if (checked)
                        break;


        }


        }

    public void ButtonOnClick(View view) {
        textView4.setText((CharSequence) input);
    }
}